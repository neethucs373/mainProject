var mongoose=require('mongoose');
var itemschema=new mongoose.Schema({
    Brand:String,
    Type:String,
    Material:String,
    Price:Number,
    url:String

})
var itemModel=mongoose.model("items",itemschema,"items");
module.exports=itemModel;