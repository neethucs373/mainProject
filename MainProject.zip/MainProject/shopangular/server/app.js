const express = require('express');
var app=new express();
var mongoose=require('mongoose');
var bodyparser=require('body-parser')
var multer = require('multer');
var url="mongodb://127.0.0.1:27017/shopsdb"
var prodModel=require('./model/item')
app.use(bodyparser.urlencoded({extended:true}))
app.use(bodyparser.json());
app.use(express.static("img"));
mongoose.connect(url,function(err){
    if(err) throw err
    else{
        console.log("Connection Established")
    }
})
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, 'UPLOADS')//folder name
    },
    filename: function (req, file, cb) {
      cb(null, file.originalname)//save file name as orginal
    }
  })
   const fileFilter=(req,file,cb)=>{
       if(file.mimetype==='image/jpeg' || file.mimetype==='image/png'){
           cb(null,true);
       
       }else{
        cb(null,false);   
       }
   }
var upload = multer({ storage: storage })
app.get("/data",function(req,res){
    // res.send({msg:"EXPRESS"})
    // var products=[
    //         {Name:"Printer",Company:"HP",Price:9000},
    //         {Name:"Scanner",Company:"Dell",Price:8000},
    //         {Name:"Camera",Company:"HP",Price:9000}
    //     ]
    //     res.send(products)
        res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE'); // If needed
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type'); // If needed
    res.setHeader('Access-Control-Allow-Credentials', true); // If needed
               prodModel.find({},function(err,result){
                   if(err) throw err
                   else{
                       res.send(result)
                   }
               }) 
})
app.post("/upload",upload.single('imageFile'),function(req,res){
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE'); // If needed
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type'); // If needed
    res.setHeader('Access-Control-Allow-Credentials', true); // If needed
    var newprd =new  prodModel();
    newprd.Brand=req.body.Brand;
    newprd.Type=req.body.Type;//eid form model folder sec eid form ejs
    newprd.Material=req.body.Material;
    newprd.Price=req.body.Price;
    newprd.url=req.file.filename;
    
    
   //console.log(req.body);
   // newemp.img.data = fs.readFileSync(req.files.photo.path)
   // newemp.img.contentType = 'image/png';
    newprd.save(function(err){
        if(err) throw err
        else{
            res.send("data added");
        }
    })
  })
  app.get("/img/:id",function(req,res){
      res.sendFile(__dirname+"/UPLOADS/"+req.params.id)
  })
  app.listen(3000,function(){
    console.log('Listening to Port 3000');
})