import { Component, OnInit,Inject } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { SESSION_STORAGE, StorageService } from 'angular-webstorage-service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
items;
cart=[];
Total=0;
prd;
d:number;
  constructor(private http:HttpClient,@Inject(SESSION_STORAGE) private storage: StorageService) {}

  ngOnInit() {
    var url="http://localhost:3000/data";
    this.http.get(url).subscribe(data=>{
      console.log(data);
      this.items=data;
    })
    if(this.storage.get("Total")!=null){
      this.Total=parseInt(this.storage.get("Total"))
    }
if(this.storage.get("cart")!=null){
  this.cart=JSON.parse(this.storage.get("cart"))
}
  }
  
      Removefromcart(d,i){
        if(this.storage.get("cart")!=null){
          this.cart=JSON.parse(this.storage.get("cart"))
        }
        
        this.cart.splice(i,1)
      
        this.storage.set("cart",JSON.stringify(this.cart))
        this.Total-=d.Price
        this.storage.set("Total",(this.cart.toString()))

      }
      delete(Name,i){
        var data={pName:Name}
        var url="http://localhost:3000/delete";
        this.http.post(url,data).subscribe(res=>{
        console.log(res)
        })
        this.items.splice(i,1)
          }

}
