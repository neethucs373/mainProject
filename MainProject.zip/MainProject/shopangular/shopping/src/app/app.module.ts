import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {RouterModule,Routes} from '@angular/router'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { CartComponent } from './cart/cart.component';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { DisplayComponent } from './display/display.component';
import {HttpClientModule} from '@angular/common/http';
import { LogoutComponent } from './logout/logout.component';
import { StorageServiceModule } from 'angular-webstorage-service';
import { ImageComponent } from './image/image.component';
import {FormsModule} from '@angular/forms'

const routes:Routes=[
 
  {path:"",component:LoginComponent},
  {path:"signup",component:SignupComponent},
  {path:"home",component:HomeComponent,
  children:
  [
    {path:"cart",component:CartComponent},
  {path:"display",component:DisplayComponent},
{path:"image",component:ImageComponent}
]
}
]
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    CartComponent,
    SignupComponent,
    LoginComponent,
    DisplayComponent,
    LogoutComponent,
    ImageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,RouterModule.forRoot(routes),HttpClientModule,
    StorageServiceModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
