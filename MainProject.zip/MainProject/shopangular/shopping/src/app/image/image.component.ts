import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup } from '@angular/forms';
import { HttpClient } from '@angular/common/http';


@Component({
  selector: 'app-image',
  templateUrl: './image.component.html',
  styleUrls: ['./image.component.css']
})
export class ImageComponent implements OnInit {
  selectedFile: File=null;

  onFileChanged(event) {
    this.selectedFile = <File>event.target.files[0];
    console.log(event);
    console.log(this.selectedFile);
  }
  SERVER_URL="http://localhost:3000/upload";
  uploadForm:FormGroup;
  constructor(private httpClient:HttpClient) { }

  ngOnInit() {

  }
 uploads(){

   const fd=new FormData();
   fd.append('imageFile',this.selectedFile,this.selectedFile.name);
   var pr ={Brand:"Paragon",Type:"Sandal",Material:"Leather",Price:1000};
   fd.append('Brand',"Paragon");
   fd.append('Type',"Sandal");
   fd.append('Material',"Leather");
   fd.append('Price',"1000");
   this.httpClient.post(this.SERVER_URL,fd)
   .subscribe(
     (response)=>{
       console.log(response);
       console.log(fd)
     },
     (error)=>{
       console.log(error,fd);
     }
   );
   console.log(this.selectedFile);
   }
 }
